# MVVM Implementation

## Scope

This is the local Android edition of the Personal Wardrobe and Outfit Management System. It uses Kotlin, Jetpack Compose and SQLite, with images stored in the application's private files. No backend server or network account service is required. The existing wardrobe theme and Chinese/English interface are retained.

The migration replaces the previous MVC account and operation coordination structure with an AndroidX ViewModel that owns observable presentation state. Existing wardrobe features are connected through named ViewModel and repository operations.

## Responsibilities

Paths below are relative to `app/src/main/java/com/wardrobe/atelier/`.

| Part | Implementation | Responsibility |
| --- | --- | --- |
| View | Compose screens in `ui/`, including `AuthScreen`, `LightWelcome` and `ProfileScreen` | Render state, collect input, maintain temporary UI state and submit user actions. |
| View event bindings | `ui/AccountCallbacks.kt` | Bind account UI events to ViewModel methods; contain no storage or validation logic. |
| ViewModel | `presentation/WardrobeViewModel.kt` | Own screen state, accept named actions, schedule work, coordinate loading and expose results. |
| Presentation state | `AppState.kt`, `presentation/AccountAction.kt` | Describe the current account, wardrobe, loading, errors and account completion information. |
| Account use cases | `domain/AccountUseCases.kt`, `domain/AccountRules.kt` | Validate account input and invoke account repository operations. |
| Repositories | `data/account/AccountRepository.kt`, `data/WardrobeRepository.kt` and their local implementations | Define and implement typed model operations. |
| Local storage | `data/LocalStore.kt` | Read and write SQLite data, validate salted PBKDF2 password hashes, and manage private image files. |
| Android host | `MainActivity.kt` | Obtain the ViewModel through its factory, host Compose and receive image-sharing intents. |

The Model includes domain rules, use cases and data access; it is not limited to database entity classes.

## Event and state flow

```text
User input
  -> Compose View
  -> named WardrobeViewModel method
  -> AccountUseCases or WardrobeRepository
  -> local repository implementation
  -> LocalStore
  -> fresh session snapshot
  -> AppState / StateFlow
  -> Compose rendering
```

`WardrobeViewModel` extends `androidx.lifecycle.ViewModel`. It maintains a private `MutableStateFlow` and exposes a read-only `StateFlow` using `asStateFlow()`. Compose collects it with `collectAsStateWithLifecycle()`.

Operations run in `viewModelScope`; blocking storage work runs on an injected worker dispatcher, which defaults to `Dispatchers.IO`. A busy-state gate prevents overlapping operations through the shared action runner. A View cannot submit SQL, call `LocalStore`, or mutate the exposed state.

The factory creates one `LocalStore` and shares it between `LocalAccountRepository` and `LocalWardrobeRepository`. This keeps the active local identity consistent with the wardrobe snapshot. Store resources are released when the ViewModel's scope finishes, rather than whenever an Activity instance is recreated.

If an operation fails, the ViewModel attempts to reload the current session snapshot. If that recovery also fails, it publishes no account and an empty wardrobe. It does not keep displaying a previous owner's data after an identity-changing operation whose refresh failed. An error remains visible so the user can retry.

## Account completion and dialogs

Account actions include registration, login, logout, nickname changes, password changes and opening the local or demo wardrobe. These methods do not accept UI success callbacks.

After a successful operation, the ViewModel increments `completionId` and sets `completedAction`. These fields describe a presentation outcome; they are not database or account identifiers. The next operation clears the previous completed action, and a failed operation does not report success.

`ProfileScreen` observes the completion identifier and closes its nickname or password dialog only when the matching action has completed and that dialog was waiting for it. Error state is displayed without pretending that the save succeeded. The ViewModel does not hold a dialog, an Activity or a Compose navigation object.

Temporary input and dialog visibility remain in the View. Password input is not stored through `rememberSaveable`.

## What changed from MVC

| Previous structure | Current implementation |
| --- | --- |
| `AccountController` handled account actions | `WardrobeViewModel` receives actions and `AccountUseCases` applies model rules. |
| `OperationCoordinator` coordinated operations | The ViewModel owns operation scheduling and observable presentation state. |
| ViewModel mainly acted as a lifecycle container | The ViewModel now owns `AppState`, loading and operation results. |
| Controller callbacks drove account dialog success | Views observe completion and error state. |
| Generic UI `perform` blocks could contain storage work | Named ViewModel methods call typed repository operations. |
| `AccountActions` connected screens to a controller | `AccountCallbacks` only binds screen events to ViewModel methods. |

This is a change to ownership and dependency direction, not a class-name substitution. There is no account controller or legacy controller bridge in the new runtime structure.

Examples of named operations include `saveGarment`, `archiveGarment`, `saveOutfit`, `savePlan`, `saveWear`, `voidWear`, `setCare`, `addLocation`, `exportBackup` and `restoreBackup`. The private ViewModel action runner remains a shared implementation detail; Views cannot pass arbitrary storage closures into it.

Some existing non-account methods retain result or navigation callbacks, such as returning an imported image path or completing an editor transition. Those callbacks carry values or UI navigation events. They do not allow the View to supply a model operation. Account success handling uses the state mechanism described above.

## Member A and team integration

Member A owns local registration and login, profile updates, password changes, logout, owner isolation, shared state and final integration. Other members should use named ViewModel methods and repository contracts for garments, outfits, plans, wear/care and statistics. Data access and business validation should remain outside Compose screens.

Current image entry uses the system picker or incoming shared images. Camera capture and automatic garment recognition are not implemented by this migration and remain follow-up work for member B. There is no remote sign-in, cloud database or cross-device synchronization.

Existing optional features, including travel capsules, remain in the source. Their presence does not change the team's agreed first-release scope; the SRS should identify which features are committed for assessment.

As the project grows, feature-specific ViewModels can replace the shared ViewModel while preserving the same View -> ViewModel -> Model direction.

## Build and installation

Open the project root containing `settings.gradle.kts` in Android Studio. Use the bundled JBR, Android SDK 36 and Build-Tools 36.0.0. The minimum supported Android API is 26.

On Windows, run `.\scripts\build-preview.ps1` from the project root to build and check the independent preview. It uses the Gradle `-PisolatedPreview` property. The resulting APK is `app/build/outputs/apk/debug/app-debug.apk`.

The preview label is **衣序 · MVVM预览** and its application ID is `com.wardrobe.atelier.light.mvvm.preview`. Without the property, the application ID remains `com.wardrobe.atelier.light`. The preview installation has its own application data and can coexist with the original installation.

## Verification

The delivered implementation passed 40 JVM unit tests. Android Lint reported 0 errors and 20 warnings. `AccountMvvmJourneyTest` and `JourneyTest` also passed together on an API 37 emulator, for a total of two device flows.

The account flow exercises registration, profile and password changes, logout, incorrect-password handling, login and account isolation. The broader journey exercises garment entry, locations, outfit favourites, travel capsules, calendar actions, batch image import and Activity recreation by rotation.

```powershell
.\gradlew.bat :app:testDebugUnitTest :app:lintDebug
.\gradlew.bat -PisolatedPreview :app:connectedDebugAndroidTest "-Pandroid.testInstrumentationRunnerArguments.class=com.wardrobe.atelier.AccountMvvmJourneyTest,com.wardrobe.atelier.JourneyTest"
```

Unit tests cover account rules, state and completion transitions, password failures, confirmation mismatches, owner changes, busy gating, snapshot recovery and lifecycle cleanup. These results support the tested paths; they do not claim exhaustive device compatibility.

## Presentation explanation

“Our application uses MVVM. Compose screens send user actions to the ViewModel and observe immutable screen state through StateFlow. The ViewModel runs operations in viewModelScope and calls use cases or repositories. The Model validates input and stores account and wardrobe data in local SQLite and private files. This separation keeps database access outside the UI and lets us test state transitions independently.”


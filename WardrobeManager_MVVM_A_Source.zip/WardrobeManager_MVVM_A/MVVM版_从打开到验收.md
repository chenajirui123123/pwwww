# 衣序 MVVM 版：从打开项目到演示验收

本指南对应 `WardrobeManager_MVVM_A` 源码。项目是 Android 单机应用，使用 Kotlin、Jetpack Compose、SQLite 和 MVVM。保留原有衣序界面配色、页面布局与中英文切换，不需要启动 Java 后端、配置服务器地址或连接远程数据库。

## 1. 先把项目打开正确

1. 将源码放到一个独立目录，例如 `D:\Projects\WardrobeManager_MVVM_A`。
2. 启动 Android Studio，选择 **Open**，打开该目录。确认目录中有 `settings.gradle.kts`、`build.gradle.kts`、`gradlew.bat` 和 `app`。
3. 不要只打开 `app`，也不要把这些文件直接复制进旧项目的 Java 文件夹。
4. 打开 **Settings → Build, Execution, Deployment → Build Tools → Gradle**，将 Gradle JDK 设为 Android Studio 自带的 JBR。
5. 在 **SDK Manager** 安装 Android SDK Platform 36 和 Build-Tools 36.0.0，等待项目同步完成。
6. 准备 Android 8.0（API 26）或更高版本的模拟器或手机。构建使用 SDK 36，设备系统可以更高；本次设备验证使用 API 37 模拟器。

如果 `local.properties` 未生成，先检查 Android Studio 的 SDK Location 是否配置正确。该文件属于每个人的本机配置，不应提交到 GitHub。

## 2. 先运行独立预览版

预览版具有独立包名，可与之前的安装同时存在，便于对照和保留原应用数据。

| 项目 | 独立预览版 | 普通运行版 |
| --- | --- | --- |
| 应用标签 | 衣序 · MVVM预览 | 衣序轻量版 |
| 包名 | `com.wardrobe.atelier.light.mvvm.preview` | `com.wardrobe.atelier.light` |
| 开启方式 | Gradle 参数 `-PisolatedPreview` | 不传该参数 |

在 Android Studio 底部打开 Terminal，确认位于项目根目录，然后运行：

```powershell
.\scripts\build-preview.ps1
```

脚本优先使用 `C:/Program Files/Android/Android Studio/jbr`，执行预览版构建、JVM 测试和 Lint。Android Studio 安装在其他位置时，请先将当前终端的 `JAVA_HOME` 设置为实际的 JBR 目录。

生成的 APK 为 `app/build/outputs/apk/debug/app-debug.apk`。可以将它拖进已启动的模拟器，或在连接设备后运行：

```powershell
.\gradlew.bat -PisolatedPreview :app:installDebug
```

随后在设备应用列表打开 **衣序 · MVVM预览**。直接点击 Android Studio 的普通 Run，一般会安装原包名的版本，因此验收时应先确认应用标签。

首次构建需要下载依赖。若失败，先查看 Build 面板的第一条实际错误；确认依赖下载和 Gradle 同步完成后再运行。

## 3. 成员 A 可以怎样验收

按下面顺序操作，分别观察成功、失败和账号切换的结果。

1. **新建账号**：使用一个新的本机账号注册。两次密码一致且符合提示规则后，进入衣橱。
2. **资料修改**：打开个人页面，修改昵称。保存成功后弹窗关闭、昵称更新；输入不合法时保留页面并显示错误。
3. **密码修改**：先输入错误的旧密码，确认操作失败；再用正确旧密码修改。退出后，旧密码应无法登录，新密码应可以登录。
4. **退出登录**：确认回到入口页面，原账号衣橱不继续显示。
5. **账号隔离**：账号甲添加一件衣物；退出后注册或登录账号乙，乙不应看到甲的衣物。再切回甲，甲的数据应仍然存在。
6. **本机与示例入口**：分别体验本机衣橱和示例衣橱，确认入口可用；正式账号验收仍使用自己创建的账号。
7. **页面重建**：操作过程中旋转模拟器，检查页面是否恢复，已经保存的资料是否仍能读取。

这里的注册登录只针对当前设备中的账号，不是互联网账号。同一账号名不会自动在另一台设备出现。

## 4. 这份代码的 MVVM 是如何工作的

实际调用方向如下：

```text
Compose View
  → WardrobeViewModel 的具名操作
  → AccountUseCases / WardrobeRepository
  → LocalAccountRepository / LocalWardrobeRepository
  → LocalStore（SQLite 与应用私有图片文件）

操作完成后：本机快照 → AppState → StateFlow → Compose 重绘
```

- **View** 是 `ui/` 中的 Compose 页面。它保存当前输入框内容、弹窗开关等界面状态，显示 ViewModel 提供的数据，并发送登录、保存衣物等用户操作。
- **ViewModel** 是 `presentation/WardrobeViewModel.kt`，继承 AndroidX `ViewModel`。它拥有可观察的 `AppState`，在 `viewModelScope` 中执行操作，将耗时的数据访问移到工作线程，并发布忙碌、成功或失败状态。
- **Model** 包含领域规则、用例、仓储与本地存储。`AccountUseCases` 负责账号输入校验与业务调用，仓储接口描述可执行的模型操作，`LocalStore` 执行 SQLite 和文件读写。

ViewModel 的内部状态可变，对界面公开的 `state` 是只读 `StateFlow`。Compose 用 `collectAsStateWithLifecycle()` 观察它。界面不持有 `LocalStore`，不编写 SQL，也不向 ViewModel 传递直接访问数据库的通用操作闭包。

`MainActivity` 负责创建界面和接收图片分享入口，通过 `by viewModels` 获取 ViewModel，不承担账号业务控制。ViewModel 的工厂创建一个共享 `LocalStore`，账号仓储与衣橱仓储共同使用它，避免当前身份与衣橱数据来源不一致。

## 5. 从 MVC 改成 MVVM 的具体变化

| 原 MVC 方案 | 本次 MVVM 方案 |
| --- | --- |
| `AccountController` 接收账号操作 | `WardrobeViewModel` 接收操作，`AccountUseCases` 执行账号规则。 |
| `OperationCoordinator` 协调忙碌状态和操作 | ViewModel 在 `viewModelScope` 中调度并发布 `AppState`。 |
| ViewModel 主要作为生命周期容器 | ViewModel 直接拥有界面状态与用户操作入口。 |
| Controller 回调通知界面成功 | 账号页面观察 `completionId`、`completedAction` 和 `error`。 |
| 部分界面通过通用 `perform` 传入存储操作 | 使用 `saveGarment`、`savePlan`、`setCare` 等具名方法和仓储接口。 |
| `AccountActions` 连接 View 与 Controller | `AccountCallbacks` 仅将界面事件绑定到 ViewModel 方法。 |

本次不是只替换类名。账号控制职责、可观察状态、异步任务归属和 View 到 Model 的调用方式都已调整。`AccountCallbacks` 不处理业务规则或存储，不是另一个 Controller。

部分衣物导入、保存页面仍有导航或结果回调，用于返回导入的图片路径或完成页面跳转；这些回调不让 View 提交任意数据库操作。账号弹窗的成功响应则已改为观察状态。

## 6. 账号弹窗为什么需要完成标识

`AppState` 中的 `completionId` 是递增的操作完成标识，不是用户 ID，也不存入账号数据库。`completedAction` 表明完成的是注册、登录、改昵称、改密码等哪一种账号操作。

以修改昵称为例：

1. View 记录“本页面正在等待昵称保存”，调用 `updateNickname`。
2. ViewModel 清除上次的成功动作，发布 `busy=true`。
3. `AccountUseCases` 校验昵称，仓储保存并重新读取当前账号快照。
4. ViewModel 发布新账号、递增的完成标识与 `UPDATE_NICKNAME`。
5. `ProfileScreen` 观察完成标识，只有当前等待的动作成功时才关闭对应弹窗。

如果失败，View 显示错误并保留可修改的输入。新操作开始时会清掉旧的成功动作，避免上次成功被误认为这次成功。

## 7. 建议按这个顺序看代码

以下路径相对 `app/src/main/java/com/wardrobe/atelier/`：

1. `AppState.kt`：先看屏幕状态中有哪些数据。
2. `presentation/AccountAction.kt`：看账号操作完成类型。
3. `presentation/WardrobeViewModel.kt`：看状态、具名操作、异步调度和错误恢复。
4. `domain/AccountUseCases.kt` 与 `domain/AccountRules.kt`：看输入校验怎样与界面分离。
5. `data/account/AccountRepository.kt` 和 `LocalAccountRepository.kt`：看账号数据操作接口及实现。
6. `data/WardrobeRepository.kt` 和 `LocalWardrobeRepository.kt`：看 B—E 业务怎样通过具名操作接入。
7. `data/LocalStore.kt`：看实际 SQLite、密码校验、账号隔离和文件读写。
8. `ui/AccountCallbacks.kt`、`ui/App.kt`、`ui/LightScreens.kt`、`ui/Profile.kt`：看输入、界面事件、状态观察与弹窗响应。
9. `MainActivity.kt`：最后看应用如何创建和连接上述对象。

单元测试在 `app/src/test/`，设备测试在 `app/src/androidTest/`。想看账号从输入到存储的完整链路，可以搜索 `updateNickname` 并依次查看 View、ViewModel、UseCase 和 Repository。

## 8. 成员 A 的工作边界与交接

你负责本机账号与基础集成：注册、登录、退出、昵称、修改密码、账号数据隔离、公共状态与错误提示、构建入口，以及全组代码接入时的架构一致性。

- 与 B 确认衣物操作使用当前账号身份、图片存入应用私有区域、删除或归档遵守小组规则。
- 与 C 确认搭配和计划通过具名方法提交，并使用本机数据模型。
- 与 D 确认实际穿着、洗护状态和历史数据的含义一致。
- 与 E 确认统计使用有效穿着记录，避免把计划直接当作实际次数。

原项目中的旅行胶囊等附加功能仍可运行；它们不自动改变已经讨论的第一版范围。最终展示应以统一后的 SRS 为准。

目前支持通过系统图片选择器及分享入口导入图片。**相机拍摄、服装自动识别、识别模型与识别结果修正尚未实现**，应作为 B 的后续任务。不要在报告里写成本次已经完成的功能。单机方案也不包含云端登录、服务器部署或跨设备同步。

小组后续代码增多时，可以按账号、衣物、搭配、穿着与统计拆分功能 ViewModel；目前使用一个共享 ViewModel 维持原页面接入，便于完成此次架构迁移。

## 9. 课堂上可以怎样解释

> Our Android application uses MVVM. Compose screens form the View and send user actions to the ViewModel. WardrobeViewModel owns immutable screen state exposed through StateFlow and runs operations in viewModelScope. Account use cases validate input, and repositories provide access to the local SQLite store and private image files. The UI observes state changes instead of accessing the database. The application works locally without a server.

展示时，依次打开 `ProfileScreen`、`WardrobeViewModel.updateNickname`、`AccountUseCases.updateNickname` 和账号仓储，讲清“输入 → 调用 → 校验 → 存储 → 状态 → 界面”的一次完整过程即可。再演示错误密码、修改成功和切换账号的数据隔离。

## 10. 已完成的验证与复现命令

本次交付已验证：

- 40 项 JVM 单元测试通过。
- Android Lint：0 个错误、20 个警告。
- API 37 模拟器上 `AccountMvvmJourneyTest` 与 `JourneyTest` 联合执行通过，共 2 条流程。
- 账号流程覆盖注册、资料修改、密码修改、退出、错误密码、重新登录和账号隔离；Journey 流程覆盖衣物录入、位置、搭配收藏、旅行胶囊、日历、批量图片和旋转重建。

```powershell
.\gradlew.bat :app:testDebugUnitTest :app:lintDebug
.\gradlew.bat -PisolatedPreview :app:connectedDebugAndroidTest "-Pandroid.testInstrumentationRunnerArguments.class=com.wardrobe.atelier.AccountMvvmJourneyTest,com.wardrobe.atelier.JourneyTest"
```

这些自动化验证说明已覆盖的路径通过，不代表所有设备和全部边界情况都已穷尽。提交前仍应在本组演示设备上走一遍实际流程，并记录最终版本号与运行设备。

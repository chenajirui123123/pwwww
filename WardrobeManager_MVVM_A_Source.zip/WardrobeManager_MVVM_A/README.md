# 衣序：单机 MVVM 版

衣橱管家的 Android 移动端项目，采用 Kotlin、Jetpack Compose 和 SQLite。此版本将原来的 MVC 账号与公共操作协调改为 MVVM，保留现有衣序主题和中英文界面，不需要服务器。

## 打开和运行

1. 在 Android Studio 中打开本目录，即包含 `settings.gradle.kts` 的目录。
2. 使用 Android Studio 自带的 JBR 作为 Gradle JDK，准备 Android SDK 36 和 Build-Tools 36.0.0。
3. 等待 Gradle 同步完成，选择 `app` 和 Android 8.0（API 26）以上的模拟器或设备。
4. 建议先在本目录终端运行 `.\scripts\build-preview.ps1`，再安装脚本生成的独立预览 APK。

独立预览版标签为“衣序 · MVVM预览”，包名为 `com.wardrobe.atelier.light.mvvm.preview`，与原包 `com.wardrobe.atelier.light` 分开保存数据。普通 Run 使用原包名；需要保留原安装的数据时，请先体验独立预览版。

详细操作见 [MVVM版：从打开到验收](MVVM版_从打开到验收.md)，英文架构说明见 [MVVM implementation](MVVM_Implementation.md)。

## 实际架构

| 层 | 文件与职责 |
| --- | --- |
| View | `ui/` 下的 Compose 页面；显示状态、收集输入、发送用户操作。 |
| ViewModel | `presentation/WardrobeViewModel.kt`；在 `viewModelScope` 中调度操作，公开只读 `StateFlow<AppState>`。 |
| Model | `domain/AccountUseCases.kt`、`domain/AccountRules.kt`、仓储接口及本地实现、`data/LocalStore.kt`；负责规则、账号、衣橱和持久化。 |

界面通过具名方法（如 `login`、`saveGarment`、`savePlan`）提交操作，不再向 ViewModel 传入直接操作数据库的通用闭包。账号弹窗通过 `completionId` 与 `completedAction` 观察成功结果，错误信息也从状态显示。

## 当前范围

成员 A 负责本机账号、个人资料、退出登录、密码修改、账号数据隔离、公共状态与集成。已有衣物、搭配、计划、穿着、洗护和统计功能通过具名仓储操作接入。图片从系统选择器或分享入口导入；拍照采集与衣物自动识别尚未实现，应由成员 B 后续补充。原有附加功能可保留演示，但是否纳入第一版应以小组最终范围为准。

账号与衣橱数据保存在当前设备，密码采用带盐 PBKDF2 校验；没有云端账号、远程数据库或跨设备同步。

## 验证

本次改造已通过 40 项 JVM 单元测试；Android Lint 为 0 个错误、20 个警告。API 37 模拟器上 `AccountMvvmJourneyTest` 与 `JourneyTest` 联合执行通过，共 2 条设备流程，覆盖账号操作以及衣物、搭配、日历、批量图片与旋转重建。

```powershell
.\gradlew.bat :app:testDebugUnitTest :app:lintDebug
.\gradlew.bat -PisolatedPreview :app:connectedDebugAndroidTest "-Pandroid.testInstrumentationRunnerArguments.class=com.wardrobe.atelier.AccountMvvmJourneyTest,com.wardrobe.atelier.JourneyTest"
```

上传 GitHub 时提交源码、Gradle Wrapper 与文档；不要提交 `local.properties`、设备数据、缓存、构建目录或签名私钥。


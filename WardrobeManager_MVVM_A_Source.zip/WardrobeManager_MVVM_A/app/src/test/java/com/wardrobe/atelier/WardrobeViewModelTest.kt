@file:OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)

package com.wardrobe.atelier

import androidx.lifecycle.ViewModelStore
import com.wardrobe.atelier.data.WardrobeRepository
import com.wardrobe.atelier.data.account.AccountRepository
import com.wardrobe.atelier.domain.Account
import com.wardrobe.atelier.domain.AccountUseCases
import com.wardrobe.atelier.domain.Garment
import com.wardrobe.atelier.domain.SessionSnapshot
import com.wardrobe.atelier.domain.Wardrobe
import com.wardrobe.atelier.presentation.AccountAction
import com.wardrobe.atelier.presentation.WardrobeViewModel
import java.lang.reflect.Proxy
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** ViewModel state and commands tested independently of Compose, Activities and SQLite. */
class WardrobeViewModelTest {
    private val stores = mutableListOf<ViewModelStore>()

    @Before fun useTestMainDispatcher() { Dispatchers.setMain(UnconfinedTestDispatcher()) }

    @After fun closeViewModels() {
        stores.forEach { it.clear() }
        Dispatchers.resetMain()
    }

    private data class Fixture(
        val accounts: FakeAccounts,
        val model: WardrobeViewModel,
        val lifecycle: ViewModelStore,
    )

    private fun fixture(
        accounts: FakeAccounts = FakeAccounts(),
        snapshot: () -> SessionSnapshot = accounts::snapshot,
        worker: CoroutineDispatcher = UnconfinedTestDispatcher(),
        closeResources: () -> Unit = {},
    ): Fixture {
        val model = WardrobeViewModel(AccountUseCases(accounts), wardrobe(snapshot), worker, closeResources)
        val lifecycle = ViewModelStore().also { it.put("under-test", model); stores += it }
        return Fixture(accounts, model, lifecycle)
    }

    @Test fun registrationPublishesPersistedAccountAsReadOnlyState() = runTest {
        val f = fixture()
        f.model.register(" Alice ", "password1", " Alice Name ", "password1")
        advanceUntilIdle()
        val state = f.model.state.value
        assertTrue(state.loaded)
        assertFalse(state.busy)
        assertNull(state.error)
        assertEquals("alice", state.account?.username)
        assertEquals("Alice Name", state.account?.nickname)
        assertEquals(1, f.accounts.registrationWrites)
        assertEquals(AccountAction.REGISTER, state.completedAction)
        assertTrue(state.completionId > 0)
        assertFalse(f.model.state is MutableStateFlow<*>)
    }

    @Test fun confirmationMismatchDoesNotWriteAnAccount() = runTest {
        val f = fixture()
        f.model.register("alice", "password1", "Alice", "different")
        advanceUntilIdle()
        assertEquals(0, f.accounts.registrationWrites)
        assertNotNull(f.model.state.value.error)
        assertNull(f.model.state.value.account)
        assertNull(f.model.state.value.completedAction)
        assertFalse(f.model.state.value.busy)
    }

    @Test fun wrongPasswordDoesNotReplaceCurrentOwnerOrWardrobe() = runTest {
        val f = fixture()
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        val before = f.model.state.value
        f.model.login("alice", "incorrect")
        advanceUntilIdle()
        assertEquals(before.account, f.model.state.value.account)
        assertEquals(before.data, f.model.state.value.data)
        assertNotNull(f.model.state.value.error)
        assertNull(f.model.state.value.completedAction)
        assertFalse(f.model.state.value.busy)
    }

    @Test fun nicknameUpdatesPublishACompletionInsteadOfCallingTheView() = runTest {
        val f = fixture()
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        val beforeId = f.model.state.value.completionId
        f.model.updateNickname(" New Name ")
        advanceUntilIdle()
        assertEquals("New Name", f.model.state.value.account?.nickname)
        assertEquals(AccountAction.UPDATE_NICKNAME, f.model.state.value.completedAction)
        assertTrue(f.model.state.value.completionId > beforeId)
        f.model.updateNickname("  ")
        advanceUntilIdle()
        assertEquals("New Name", f.model.state.value.account?.nickname)
        assertNotNull(f.model.state.value.error)
        assertNull(f.model.state.value.completedAction)
    }

    @Test fun passwordConfirmationFailureDoesNotOverwriteTheSavedPassword() = runTest {
        val f = fixture()
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        f.model.changePassword("password1", "newpass23", "mismatch")
        advanceUntilIdle()
        assertEquals(0, f.accounts.passwordChanges)
        assertNotNull(f.model.state.value.error)
        f.model.logout()
        advanceUntilIdle()
        f.model.login("alice", "password1")
        advanceUntilIdle()
        assertNull(f.model.state.value.error)
        assertEquals("alice", f.model.state.value.account?.username)
    }

    @Test fun changingPasswordRejectsOldCredentialsAndAcceptsNewCredentials() = runTest {
        val f = fixture()
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        f.model.changePassword("password1", "newpass23", "newpass23")
        advanceUntilIdle()
        assertEquals(AccountAction.CHANGE_PASSWORD, f.model.state.value.completedAction)
        assertEquals(1, f.accounts.passwordChanges)
        f.model.logout()
        advanceUntilIdle()
        f.model.login("alice", "password1")
        advanceUntilIdle()
        assertNotNull(f.model.state.value.error)
        assertNull(f.model.state.value.account)
        f.model.login("alice", "newpass23")
        advanceUntilIdle()
        assertNull(f.model.state.value.error)
        assertEquals(AccountAction.LOGIN, f.model.state.value.completedAction)
        assertEquals("alice", f.model.state.value.account?.username)
    }

    @Test fun logoutPublishesAnEmptyAccountAndWardrobe() = runTest {
        val f = fixture()
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        assertFalse(f.model.state.value.data.garments.isEmpty())
        f.model.logout()
        advanceUntilIdle()
        assertNull(f.model.state.value.account)
        assertEquals(Wardrobe(), f.model.state.value.data)
        assertEquals(AccountAction.LOGOUT, f.model.state.value.completedAction)
    }

    @Test fun switchingAccountsPublishesOnlyTheSelectedOwnersData() = runTest {
        val f = fixture()
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        val aliceGarment = f.model.state.value.data.garments.single()
        f.model.logout()
        advanceUntilIdle()
        f.model.register("bobby", "password2", "Bob", "password2")
        advanceUntilIdle()
        val bobGarment = f.model.state.value.data.garments.single()
        assertNotEquals(aliceGarment.id, bobGarment.id)
        assertFalse(f.model.state.value.data.garments.any { it.id == aliceGarment.id })
        f.model.logout()
        advanceUntilIdle()
        f.model.login("alice", "password1")
        advanceUntilIdle()
        assertEquals(aliceGarment, f.model.state.value.data.garments.single())
    }

    @Test fun busyGateRejectsDuplicateCommandsAndClearsPreviousCompletion() = runTest {
        val worker = QueuedDispatcher()
        val f = fixture(worker = worker)
        worker.drain() // Complete the initial snapshot load, if performed by the ViewModel.
        advanceUntilIdle()
        f.model.register("alice", "password1", "Alice", "password1")
        assertTrue(f.model.state.value.busy)
        f.model.register("bobby", "password2", "Bob", "password2")
        worker.drain()
        advanceUntilIdle()
        assertEquals(1, f.accounts.registrationWrites)
        assertEquals("alice", f.model.state.value.account?.username)
        val completedId = f.model.state.value.completionId
        f.model.updateNickname("New Name")
        assertTrue(f.model.state.value.busy)
        assertNull(f.model.state.value.completedAction)
        worker.drain()
        advanceUntilIdle()
        assertEquals("New Name", f.model.state.value.account?.nickname)
        assertTrue(f.model.state.value.completionId > completedId)
        assertFalse(f.model.state.value.busy)
    }

    @Test fun failedSnapshotAfterIdentityChangeNeverRetainsPreviousOwnersData() = runTest {
        val accounts = FakeAccounts()
        var failReads = false
        val f = fixture(accounts, snapshot = {
            if (failReads) error("Database read failed")
            accounts.snapshot()
        })
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        assertEquals("alice", f.model.state.value.account?.username)
        failReads = true
        f.model.register("bobby", "password2", "Bob", "password2")
        advanceUntilIdle()
        assertEquals("bobby", accounts.currentAccount()?.username)
        assertNull(f.model.state.value.account)
        assertEquals(Wardrobe(), f.model.state.value.data)
        assertNotNull(f.model.state.value.error)
        assertNull(f.model.state.value.completedAction)
        assertFalse(f.model.state.value.busy)
    }

    @Test fun transientSnapshotFailureRecoversTheNewOwnerWithoutSuccessCompletion() = runTest {
        val accounts = FakeAccounts()
        var failuresRemaining = 0
        val f = fixture(accounts, snapshot = {
            if (failuresRemaining > 0) { failuresRemaining--; error("Temporary read failure") }
            accounts.snapshot()
        })
        f.model.register("alice", "password1", "Alice", "password1")
        advanceUntilIdle()
        failuresRemaining = 1
        f.model.register("bobby", "password2", "Bob", "password2")
        advanceUntilIdle()
        assertEquals("bobby", f.model.state.value.account?.username)
        assertEquals("Owned by bobby", f.model.state.value.data.garments.single().name)
        assertNotNull(f.model.state.value.error)
        assertNull(f.model.state.value.completedAction)
        assertFalse(f.model.state.value.busy)
    }

    @Test fun clearingTheLifecycleClosesOwnedResourcesOnce() = runTest {
        var closes = 0
        val f = fixture(closeResources = { closes++ })
        advanceUntilIdle()
        f.lifecycle.clear()
        advanceUntilIdle()
        assertEquals(1, closes)
        f.lifecycle.clear()
        assertEquals(1, closes)
    }

    /** A fail-fast snapshot-only double; these tests never invoke clothing or file operations. */
    private fun wardrobe(snapshot: () -> SessionSnapshot): WardrobeRepository =
        Proxy.newProxyInstance(
            WardrobeRepository::class.java.classLoader,
            arrayOf(WardrobeRepository::class.java),
        ) { proxy, method, args ->
            when (method.name) {
                "snapshot" -> snapshot()
                "toString" -> "SnapshotOnlyWardrobeRepository"
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.firstOrNull()
                else -> error("Unexpected business operation in account test: ${method.name}")
            }
        } as WardrobeRepository

    private class QueuedDispatcher : CoroutineDispatcher() {
        private val tasks = ConcurrentLinkedQueue<Runnable>()
        override fun dispatch(context: CoroutineContext, block: Runnable) { tasks += block }
        fun drain() { while (true) (tasks.poll() ?: break).run() }
    }

    private class FakeAccounts : AccountRepository {
        private data class Entry(var account: Account, var password: String, val wardrobe: Wardrobe)
        private val entries = linkedMapOf<String, Entry>()
        private var current: Entry? = null
        var registrationWrites = 0
            private set
        var passwordChanges = 0
            private set

        override fun currentAccount(): Account? = current?.account
        override fun register(username: String, password: String, nickname: String): Account {
            val key = username.trim().lowercase(Locale.ROOT)
            require(key !in entries) { "Account already exists" }
            val id = entries.size.toLong() + 1
            val account = Account(id, key, nickname.trim())
            current = Entry(account, password, Wardrobe(garments = listOf(Garment(id = id, name = "Owned by $key"))))
            entries[key] = current!!
            registrationWrites++
            return account
        }
        override fun login(username: String, password: String): Account {
            val candidate = entries[username.trim().lowercase(Locale.ROOT)]
            require(candidate != null && candidate.password == password) { "Incorrect account or password" }
            current = candidate
            return candidate.account
        }
        override fun logout() { current = null }
        override fun updateNickname(nickname: String) {
            val entry = checkNotNull(current)
            entry.account = entry.account.copy(nickname = nickname.trim())
        }
        override fun changePassword(oldPassword: String, newPassword: String) {
            val entry = checkNotNull(current)
            require(entry.password == oldPassword) { "Incorrect current password" }
            entry.password = newPassword
            passwordChanges++
        }
        override fun openLocalWardrobe(): Account = openSpace("wardrobe_local", "Local")
        override fun openDemoWardrobe(): Account = openSpace("wardrobe_demo", "Demo")
        private fun openSpace(username: String, name: String): Account {
            val entry = entries[username]
            if (entry != null) { current = entry; return entry.account }
            return register(username, "internal-only", name)
        }
        fun snapshot() = SessionSnapshot(currentAccount(), current?.wardrobe ?: Wardrobe())
    }
}

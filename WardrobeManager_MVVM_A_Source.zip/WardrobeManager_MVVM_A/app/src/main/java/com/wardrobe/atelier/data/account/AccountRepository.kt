package com.wardrobe.atelier.data.account

import com.wardrobe.atelier.domain.Account

/** Blocking model operations. The ViewModel dispatches them to a worker thread. */
interface AccountRepository {
    fun currentAccount(): Account?
    fun register(username: String, password: String, nickname: String): Account
    fun login(username: String, password: String): Account
    fun logout()
    fun updateNickname(nickname: String)
    fun changePassword(oldPassword: String, newPassword: String)
    fun openLocalWardrobe(): Account
    fun openDemoWardrobe(): Account
}

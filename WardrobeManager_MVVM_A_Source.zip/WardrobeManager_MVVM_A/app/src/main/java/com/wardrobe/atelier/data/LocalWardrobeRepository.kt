package com.wardrobe.atelier.data

import android.net.Uri
import com.wardrobe.atelier.domain.Capsule
import com.wardrobe.atelier.domain.Care
import com.wardrobe.atelier.domain.Garment
import com.wardrobe.atelier.domain.Outfit
import com.wardrobe.atelier.domain.Plan
import com.wardrobe.atelier.domain.SessionSnapshot
import com.wardrobe.atelier.domain.Wardrobe
import com.wardrobe.atelier.domain.Wear

/**
 * Adapts the existing SQLite and private-image implementation to the model interface.
 * Account and wardrobe repositories must share this same LocalStore instance.
 */
class LocalWardrobeRepository(private val store: LocalStore) : WardrobeRepository {
    override fun snapshot(): SessionSnapshot {
        val account = store.account()
        return SessionSnapshot(account, if (account == null) Wardrobe() else store.snapshot())
    }

    override fun importImage(uri: Uri): String = store.importImage(uri)
    override fun importImages(uris: List<Uri>): List<String> = store.importImages(uris)
    override fun discardDraftImages(paths: List<String>) { store.discardDraftImages(paths) }

    override fun saveGarment(garment: Garment) { store.saveGarment(garment) }
    override fun saveQuickGarment(garment: Garment) { store.saveQuickGarment(garment) }
    override fun saveQuickGarments(garments: List<Garment>) { store.saveQuickGarments(garments) }
    override fun archiveGarment(id: Long, archived: Boolean) { store.archive(id, archived) }
    override fun moveGarments(ids: List<Long>, location: String) { store.moveGarments(ids, location) }

    override fun saveOutfit(outfit: Outfit) { store.saveOutfit(outfit) }
    override fun deleteOutfit(id: Long) { store.deleteOutfit(id) }
    override fun savePlan(plan: Plan) { store.savePlan(plan) }
    override fun deletePlan(id: Long) { store.deletePlan(id) }
    override fun saveWear(wear: Wear) { store.saveWear(wear) }
    override fun voidWear(id: Long) { store.voidWear(id) }
    override fun setCare(id: Long, state: Care) { store.setCare(id, state) }

    override fun saveCapsule(capsule: Capsule) { store.saveCapsule(capsule) }
    override fun setCapsulePacked(capsuleId: Long, garmentId: Long, checked: Boolean) {
        store.setCapsulePacked(capsuleId, garmentId, checked)
    }
    override fun resetCapsulePacked(id: Long) { store.resetCapsulePacked(id) }
    override fun deleteCapsule(id: Long) { store.deleteCapsule(id) }

    override fun addLocation(name: String) { store.addLocation(name) }
    override fun renameLocation(oldName: String, newName: String) { store.renameLocation(oldName, newName) }
    override fun deleteLocation(name: String) { store.deleteLocation(name) }
    override fun exportBackup(uri: Uri, passphrase: String) { store.exportBackup(uri, passphrase) }
    override fun restoreBackup(uri: Uri, passphrase: String) { store.importBackup(uri, passphrase) }
}

package com.wardrobe.atelier.presentation

/** Identifies a completed account operation in immutable UI state. */
enum class AccountAction {
    REGISTER, LOGIN, LOGOUT, UPDATE_NICKNAME, CHANGE_PASSWORD, OPEN_LOCAL, OPEN_DEMO,
}

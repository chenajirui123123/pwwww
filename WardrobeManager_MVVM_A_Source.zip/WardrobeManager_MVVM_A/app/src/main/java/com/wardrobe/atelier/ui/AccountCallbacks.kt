package com.wardrobe.atelier.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.wardrobe.atelier.presentation.WardrobeViewModel

/** Plain UI intents, bound to ViewModel methods by the app's composition root. */
data class AccountCallbacks(
    val register: (String, String, String, String) -> Unit,
    val login: (String, String) -> Unit,
    val logout: () -> Unit,
    val updateNickname: (String) -> Unit,
    val changePassword: (String, String, String) -> Unit,
    val openLocalWardrobe: () -> Unit,
    val openDemoWardrobe: () -> Unit,
)

@Composable
internal fun rememberAccountCallbacks(viewModel: WardrobeViewModel): AccountCallbacks = remember(viewModel) {
    AccountCallbacks(
        register = viewModel::register,
        login = viewModel::login,
        logout = viewModel::logout,
        updateNickname = viewModel::updateNickname,
        changePassword = viewModel::changePassword,
        openLocalWardrobe = viewModel::openLocalWardrobe,
        openDemoWardrobe = viewModel::openDemoWardrobe,
    )
}

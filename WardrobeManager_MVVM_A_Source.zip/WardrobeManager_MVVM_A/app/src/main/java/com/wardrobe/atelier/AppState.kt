package com.wardrobe.atelier

import com.wardrobe.atelier.domain.Account
import com.wardrobe.atelier.domain.Wardrobe
import com.wardrobe.atelier.presentation.AccountAction

/** Immutable screen state, published by WardrobeViewModel and observed by Compose. */
data class AppState(
    val loaded: Boolean = false,
    val account: Account? = null,
    val data: Wardrobe = Wardrobe(),
    val busy: Boolean = false,
    val error: String? = null,
    val message: String? = null,
    val completionId: Long = 0,
    val completedAction: AccountAction? = null,
)

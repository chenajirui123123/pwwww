package com.wardrobe.atelier.data

import android.net.Uri
import com.wardrobe.atelier.domain.Capsule
import com.wardrobe.atelier.domain.Care
import com.wardrobe.atelier.domain.Garment
import com.wardrobe.atelier.domain.Outfit
import com.wardrobe.atelier.domain.Plan
import com.wardrobe.atelier.domain.SessionSnapshot
import com.wardrobe.atelier.domain.Wear

/**
 * Blocking local model operations. ViewModel dispatches these calls to its worker dispatcher.
 * Views receive domain values and operation results, never a LocalStore receiver or SQL access.
 */
interface WardrobeRepository {
    fun snapshot(): SessionSnapshot

    fun importImage(uri: Uri): String
    fun importImages(uris: List<Uri>): List<String>
    fun discardDraftImages(paths: List<String>)

    fun saveGarment(garment: Garment)
    fun saveQuickGarment(garment: Garment)
    fun saveQuickGarments(garments: List<Garment>)
    fun archiveGarment(id: Long, archived: Boolean)
    fun moveGarments(ids: List<Long>, location: String)

    fun saveOutfit(outfit: Outfit)
    fun deleteOutfit(id: Long)
    fun savePlan(plan: Plan)
    fun deletePlan(id: Long)
    fun saveWear(wear: Wear)
    fun voidWear(id: Long)
    fun setCare(id: Long, state: Care)

    fun saveCapsule(capsule: Capsule)
    fun setCapsulePacked(capsuleId: Long, garmentId: Long, checked: Boolean)
    fun resetCapsulePacked(id: Long)
    fun deleteCapsule(id: Long)

    fun addLocation(name: String)
    fun renameLocation(oldName: String, newName: String)
    fun deleteLocation(name: String)
    fun exportBackup(uri: Uri, passphrase: String)
    fun restoreBackup(uri: Uri, passphrase: String)
}

package com.wardrobe.atelier.domain

import com.wardrobe.atelier.data.account.AccountRepository

/** Model-side account operations; independent of Compose and ViewModel display state. */
class AccountUseCases(private val repository: AccountRepository) {
    fun register(username: String, password: String, nickname: String, confirmation: String): Account {
        AccountRules.validateRegistration(username, password, nickname, confirmation)
        return repository.register(username, password, nickname)
    }

    fun login(username: String, password: String): Account {
        AccountRules.validateLogin(username, password)
        return repository.login(username, password)
    }

    fun logout() = repository.logout()

    fun updateNickname(nickname: String) {
        AccountRules.validateNickname(nickname)
        repository.updateNickname(nickname)
    }

    fun changePassword(oldPassword: String, newPassword: String, confirmation: String) {
        AccountRules.validatePasswordChange(oldPassword, newPassword, confirmation)
        repository.changePassword(oldPassword, newPassword)
    }

    fun openLocalWardrobe() = repository.openLocalWardrobe()
    fun openDemoWardrobe() = repository.openDemoWardrobe()
}

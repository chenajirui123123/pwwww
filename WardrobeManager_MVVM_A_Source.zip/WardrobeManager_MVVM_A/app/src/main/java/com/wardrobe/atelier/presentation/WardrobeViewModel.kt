package com.wardrobe.atelier.presentation

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.wardrobe.atelier.AppState
import com.wardrobe.atelier.data.LocalStore
import com.wardrobe.atelier.data.LocalWardrobeRepository
import com.wardrobe.atelier.data.WardrobeRepository
import com.wardrobe.atelier.data.account.LocalAccountRepository
import com.wardrobe.atelier.domain.AccountUseCases
import com.wardrobe.atelier.domain.Capsule
import com.wardrobe.atelier.domain.Care
import com.wardrobe.atelier.domain.Garment
import com.wardrobe.atelier.domain.Outfit
import com.wardrobe.atelier.domain.Plan
import com.wardrobe.atelier.domain.Wardrobe
import com.wardrobe.atelier.domain.Wear
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Presentation state and user-intent handling for this local app.
 * Views cannot submit SQL, access LocalStore, or mutate the exposed StateFlows.
 */
class WardrobeViewModel(
    private val accounts: AccountUseCases,
    private val repository: WardrobeRepository,
    private val workerDispatcher: CoroutineDispatcher = Dispatchers.IO,
    closeResources: () -> Unit = {},
) : ViewModel() {
    private val mutableState = MutableStateFlow(AppState())
    val state = mutableState.asStateFlow()
    private val incomingImage = MutableStateFlow<Uri?>(null)
    val sharedImage = incomingImage.asStateFlow()

    init {
        // A retained ViewModel owns the job and the database lifetime, not an Activity.
        viewModelScope.coroutineContext[Job]?.invokeOnCompletion { closeResources() }
        refresh()
    }

    private fun <T> launchOperation(
        successMessage: String? = null,
        accountAction: AccountAction? = null,
        after: () -> Unit = {},
        onResult: (T) -> Unit = {},
        operation: () -> T,
    ): Job? {
        while (true) {
            val before = mutableState.value
            if (before.busy) return null
            val loading = before.copy(busy = true, error = null, message = null, completedAction = null)
            if (mutableState.compareAndSet(before, loading)) break
        }
        return viewModelScope.launch {
            val result: T
            try {
                val (value, snapshot) = withContext(workerDispatcher) {
                    operation() to repository.snapshot()
                }
                result = value
                mutableState.value = AppState(
                    loaded = true, account = snapshot.account, data = snapshot.data,
                    message = successMessage,
                    completionId = mutableState.value.completionId + 1,
                    completedAction = accountAction,
                )
            } catch (cancelled: CancellationException) {
                mutableState.value = mutableState.value.copy(busy = false)
                throw cancelled
            } catch (failure: Exception) {
                // A model operation may have changed the owner before refreshing failed.
                val recovered = try {
                    withContext(workerDispatcher) { repository.snapshot() }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) { null }
                mutableState.value = AppState(
                    loaded = true, account = recovered?.account, data = recovered?.data ?: Wardrobe(),
                    error = failure.message ?: "操作失败，请重试",
                    completionId = mutableState.value.completionId,
                )
                return@launch
            }
            // Existing B–E navigation/result callbacks carry values only, never model operations.
            onResult(result)
            after()
        }
    }

    fun refresh() { launchOperation { } }

    fun register(username: String, password: String, nickname: String, confirmation: String) {
        launchOperation("欢迎来到衣序", AccountAction.REGISTER) {
            accounts.register(username, password, nickname, confirmation)
        }
    }

    fun login(username: String, password: String) {
        launchOperation("欢迎来到衣序", AccountAction.LOGIN) { accounts.login(username, password) }
    }

    fun logout() {
        launchOperation("已退出登录", AccountAction.LOGOUT, after = { incomingImage.value = null }) {
            accounts.logout()
        }
    }

    fun updateNickname(nickname: String) {
        launchOperation("昵称已更新", AccountAction.UPDATE_NICKNAME) { accounts.updateNickname(nickname) }
    }

    fun changePassword(oldPassword: String, newPassword: String, confirmation: String) {
        launchOperation("密码已修改", AccountAction.CHANGE_PASSWORD) {
            accounts.changePassword(oldPassword, newPassword, confirmation)
        }
    }

    fun openLocalWardrobe() {
        launchOperation(accountAction = AccountAction.OPEN_LOCAL) { accounts.openLocalWardrobe() }
    }

    fun openDemoWardrobe() {
        launchOperation(accountAction = AccountAction.OPEN_DEMO) { accounts.openDemoWardrobe() }
    }

    fun queueSharedImage(uri: Uri) { incomingImage.value = uri }
    fun consumeSharedImage(uri: Uri) { if (incomingImage.value == uri) incomingImage.value = null }

    fun importImage(uri: Uri, onImported: (String) -> Unit) {
        launchOperation(onResult = onImported) { repository.importImage(uri) }
    }

    fun importSharedImage(uri: Uri, onImported: (String) -> Unit) {
        launchOperation(onResult = { path: String -> consumeSharedImage(uri); onImported(path) }) {
            repository.importImage(uri)
        }
    }

    fun importImages(uris: List<Uri>, onImported: (List<String>) -> Unit) {
        launchOperation(onResult = onImported) { repository.importImages(uris) }
    }

    fun discardDraftImages(paths: List<String>, after: () -> Unit = {}) {
        launchOperation(after = after) { repository.discardDraftImages(paths) }
    }

    fun saveGarment(garment: Garment, successMessage: String? = "衣物已保存", after: () -> Unit = {}) {
        launchOperation(successMessage, after = after) { repository.saveGarment(garment) }
    }

    fun saveQuickGarment(garment: Garment, successMessage: String? = "衣物已记下", after: () -> Unit = {}) {
        launchOperation(successMessage, after = after) { repository.saveQuickGarment(garment) }
    }

    fun saveQuickGarments(garments: List<Garment>, successMessage: String? = "衣物已保存", after: () -> Unit = {}) {
        launchOperation(successMessage, after = after) { repository.saveQuickGarments(garments) }
    }

    fun archiveGarment(id: Long, archived: Boolean, after: () -> Unit = {}) {
        launchOperation(if (archived) "衣物已归档" else "衣物已恢复", after = after) {
            repository.archiveGarment(id, archived)
        }
    }

    fun moveGarments(ids: List<Long>, location: String, after: () -> Unit = {}) {
        launchOperation("位置已更新", after = after) { repository.moveGarments(ids, location) }
    }

    fun saveOutfit(outfit: Outfit, successMessage: String? = "搭配已保存", after: () -> Unit = {}) {
        launchOperation(successMessage, after = after) { repository.saveOutfit(outfit) }
    }

    fun deleteOutfit(id: Long, successMessage: String? = "搭配已删除", after: () -> Unit = {}) {
        launchOperation(successMessage, after = after) { repository.deleteOutfit(id) }
    }

    fun savePlan(plan: Plan, after: () -> Unit = {}) {
        launchOperation("计划已保存", after = after) { repository.savePlan(plan) }
    }
    fun deletePlan(id: Long) { launchOperation("计划已删除") { repository.deletePlan(id) } }
    fun saveWear(wear: Wear, after: () -> Unit = {}) {
        launchOperation("实际穿着已保存", after = after) { repository.saveWear(wear) }
    }
    fun voidWear(id: Long, after: () -> Unit = {}) {
        launchOperation("记录已撤销", after = after) { repository.voidWear(id) }
    }
    fun setCare(id: Long, state: Care) {
        launchOperation("洗护状态已更新") { repository.setCare(id, state) }
    }
    fun saveCapsule(capsule: Capsule, successMessage: String? = "行李胶囊已保存", after: () -> Unit = {}) {
        launchOperation(successMessage, after = after) { repository.saveCapsule(capsule) }
    }
    fun setCapsulePacked(capsuleId: Long, garmentId: Long, checked: Boolean) {
        launchOperation { repository.setCapsulePacked(capsuleId, garmentId, checked) }
    }
    fun resetCapsulePacked(id: Long) {
        launchOperation("已重新打开清单") { repository.resetCapsulePacked(id) }
    }
    fun deleteCapsule(id: Long, after: () -> Unit = {}) {
        launchOperation("已删除行李胶囊", after = after) { repository.deleteCapsule(id) }
    }
    fun addLocation(name: String, after: () -> Unit = {}) {
        launchOperation("位置已添加", after = after) { repository.addLocation(name) }
    }
    fun renameLocation(oldName: String, newName: String, after: () -> Unit = {}) {
        launchOperation("位置已更新", after = after) { repository.renameLocation(oldName, newName) }
    }
    fun deleteLocation(name: String) { launchOperation("位置已删除") { repository.deleteLocation(name) } }
    fun exportBackup(uri: Uri, passphrase: String) {
        launchOperation("加密备份已导出") { repository.exportBackup(uri, passphrase) }
    }
    fun restoreBackup(uri: Uri, passphrase: String) {
        launchOperation("备份已恢复") { repository.restoreBackup(uri, passphrase) }
    }

    fun error(text: String) { mutableState.value = mutableState.value.copy(error = text) }
    fun notify(text: String) { mutableState.value = mutableState.value.copy(message = text) }
    fun clearError() { mutableState.value = mutableState.value.copy(error = null) }
    fun clearMessage() { mutableState.value = mutableState.value.copy(message = null) }

    class Factory(context: Context) : ViewModelProvider.Factory {
        private val applicationContext = context.applicationContext
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            require(modelClass.isAssignableFrom(WardrobeViewModel::class.java)) { "Unknown ViewModel" }
            val store = LocalStore(applicationContext)
            return WardrobeViewModel(
                AccountUseCases(LocalAccountRepository(store)), LocalWardrobeRepository(store),
                closeResources = store::close,
            ) as T
        }
    }
}

$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
$studioJbr = 'C:/Program Files/Android/Android Studio/jbr'
if (Test-Path -LiteralPath $studioJbr) {
    $env:JAVA_HOME = $studioJbr
}
if (-not $env:JAVA_HOME) {
    throw 'Configure JAVA_HOME to the Android Studio bundled JDK before building.'
}
Push-Location -LiteralPath $projectPath
try {
    & .\gradlew.bat -PisolatedPreview :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle failed with exit code $LASTEXITCODE" }
    Write-Host 'MVVM preview APK: app/build/outputs/apk/debug/app-debug.apk'
    Write-Host 'Application ID: com.wardrobe.atelier.light.mvvm.preview'
} finally {
    Pop-Location
}

# A 模块：从打开工程到完成验收

## 第一步：打开这次的独立工程

本工程基于你提供的 `pwwww-main` 改造，保留现有 Kotlin、Compose、SQLite 和衣序主题。
这是 A 模块的 MVC 实施阶段，不是之前的 Java/XML＋服务器工程。

1. 解压整个源码包到新目录，例如 `D:\Projects\WardrobeManager_MVC_A`。
2. Android Studio → File → Open，选择该目录。
3. 选中的目录下应同时有 `settings.gradle.kts`、`app`、`gradle`、`gradlew.bat`。
4. 等待 Gradle 同步。使用 Android Studio 自带 JDK，并安装 Android SDK 36 / Build-Tools 36.0.0。
5. 首次同步保持联网；已缓存依赖后可离线构建和运行。

源码副本没有覆盖桌面的原工程，也没有复制任何账号数据库。

## 第二步：先体验独立预览版

附带 APK 的应用名称为“衣序 · A模块预览”，包名为 `com.wardrobe.atelier.light.preview`。
它与原来的衣序轻量版分开安装、分开保存数据。第一次使用需要重新注册测试账号。
本应用为单机版，不需要启动服务器，不需要填写 IP 地址。

Android Studio 默认 Run 构建普通包。若只想使用独立预览环境，在工程终端运行：

```powershell
.\gradlew.bat -PisolatedPreview :app:assembleDebug
```

生成文件为 `app/build/outputs/apk/debug/app-debug.apk`，可以拖到 Android 模拟器中安装。
确认安装的是预览版后，依次操作：

1. 欢迎页选择“已有独立账号？登录或注册”。
2. 点击“还没有账号？创建一个”。
3. 输入账号、昵称、密码和确认密码，点击“注册并进入”。
4. 进入“我的 → 账号与设置”，修改昵称和密码。
5. 退出后，使用新的密码重新登录。

原有“本机空间”和“示例衣橱”仍保留，表示不同用途的本地空间；它们不等于密码保护账号。
账号使用 3–24 位字母、数字或下划线；密码为 8–64 个字符；昵称为去除首尾空白后 1–20 个字符。
密码不会自动去除空格。

## 第三步：先看 Model，再看 Controller，最后看 View

以下路径均相对于 `app/src/main/java/com/wardrobe/atelier/`。

| 顺序 | 文件 | 阅读重点 |
|---|---|---|
| 1 | `domain/AccountRules.kt` | 账号、昵称、密码及两次确认的业务规则 |
| 2 | `data/account/AccountRepository.kt` | 控制器可以使用哪些账号数据操作 |
| 3 | `data/account/LocalAccountRepository.kt` | 将数据操作交给原有 LocalStore，不接触界面 |
| 4 | `controller/AccountActions.kt` | 页面可以发送哪些明确的用户操作 |
| 5 | `controller/AccountController.kt` | 登录、注册等操作的协调流程 |
| 6 | `controller/OperationCoordinator.kt` | 后台执行、加载状态、失败恢复、刷新当前账号与衣橱 |
| 7 | `ui/App.kt` 中的 `AuthScreen` | 页面收集输入并调用 AccountActions |
| 8 | `ui/Profile.kt` 中的 `ProfileScreen` | 昵称、密码和退出如何接入控制器 |
| 9 | `MainActivity.kt` 中的 `WardrobeViewModel` | 创建并持有对象，交由 Android 管理生命周期 |

登录调用链：

```text
AuthScreen 点击“登录”
→ AccountActions.login(username, password)
→ AccountController 协调 AccountRules 校验
→ AccountRepository.login
→ LocalAccountRepository → LocalStore → 本机 SQLite
→ OperationCoordinator 读取当前账号及对应衣橱
→ 发布新的 AppState
→ Compose 根据状态显示衣橱或错误提示
```

Controller 不持有 Activity、TextField 或其他 Compose 控件；Repository 不决定弹什么对话框。
页面中不再传入 `LocalStore.() -> Unit` 类型的账号数据操作闭包。
ViewModel 保留生命周期容器和应用装配职责，不再负责账号业务协调。

## 第四步：理解这次已经改好的内容

- 注册、登录、退出、昵称修改、密码修改、本机空间和示例空间入口已接入具名账号控制器。
- 账号页面接收 AccountActions，不直接操作 LocalStore。
- 账号 Repository 与其他模块共用一个私有 LocalStore，避免各自缓存不同登录身份。
- 操作共用协调器，忙碌期间不重复执行新的数据库任务。
- 数据库操作在后台执行；完成后同时更新账号和其衣橱快照。
- 切换身份后刷新失败时，尝试从模型恢复；恢复仍失败则清空显示数据，不继续显示上一个账号的衣橱。
- 密码和确认密码不放入可恢复页面状态，切换注册/登录模式时清空。
- 登录和退出先确认本机身份持久化成功，再改变内存中的当前身份。
- 保留现有 PBKDF2 加盐密码校验和 SQLite 表结构，没有增加网络接口或服务器。
- 保留原有主题、图片展示、页面导航和中英文切换；补充新增标签的翻译。

## 第五步：完成你的 A 模块检查

| 检查项 | 预期结果 |
|---|---|
| 注册新账号 | 创建账号并进入自己的衣橱 |
| 两次密码不同 | 显示明确错误，账号不写入数据库 |
| 昵称为空或过长 | 拒绝保存 |
| 修改昵称 | 个人页面和再次进入后的内容一致 |
| 修改密码 | 原密码不再可登录，新密码能登录 |
| 退出 | 返回欢迎页；账号及衣物仍保存在本机 |
| 切换账号 | B 账号看不到 A 账号衣物，重新登录 A 后记录仍在 |
| 重复点击提交 | 同一时刻不重复运行数据操作 |
| 页面重建 | 账号输入可恢复，密码输入被清空 |

账号数据保存在应用私有目录，卸载或清除应用数据会移除内容。预览版用于验证，正式使用前仍需保留原数据备份。

## 第六步：怎样向老师说明 MVC

可以选择“修改昵称”演示：

1. 打开 `ProfileScreen`，指出它只负责显示和收集昵称。
2. 跳到 `AccountController.updateNickname()`，指出它接收操作并协调校验及保存。
3. 跳到 `AccountRules.validateNickname()` 和 `LocalAccountRepository.updateNickname()`。
4. 展示 LocalStore 将当前账号昵称写入 SQLite。
5. 回到 OperationCoordinator，说明读取结果后更新 AppState，页面据此刷新。

不能只展示文件夹名字，也不要称整套应用已全部完成 MVC 改造。
老师 Lecture 14 没有包含在本次材料中，展示前应核对其 MVC 定义，特别是 ViewModel 仅作生命周期容器的安排。

## 第七步：把哪些规则交给 B–E

本次保留 `LegacyModuleController` 和 ViewModel 的 `perform()` 兼容入口，供尚未迁移的模块继续运行。
兼容入口不代表它们已经完成 MVC。其他成员应逐步新增具名 Controller 和对应 Repository。

| 成员 | 后续接入 |
|---|---|
| B | GarmentController：衣物保存、拍照结果、离线识别草稿确认与图片管理 |
| C | OutfitController：搭配、计划及与实际记录的接口 |
| D | WearCareController：实际穿着、作废和洗护变更 |
| E | StatisticsController：有效记录统计和闲置规则 |

拍照和离线衣物识别仍需 B 实现，本次不包含识别模型，也没有把相册导入冒充自动识别。
你负责公共接入方式和协调；其他成员负责实现与验证自己模块。

## 测试命令

```powershell
.\gradlew.bat -PisolatedPreview :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
.\gradlew.bat -PisolatedPreview :app:connectedDebugAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.wardrobe.atelier.AccountMvcJourneyTest
```

第二条命令需要连接模拟器，并限定在独立预览包运行。新增的账号界面测试会创建随机测试账号，不指向普通安装版。
Espresso 3.7.0 仅为测试依赖，用于解决旧测试库调用已移除 InputManager 接口的问题；不进入正式应用运行逻辑。

具体执行结果见随包的验证摘要。

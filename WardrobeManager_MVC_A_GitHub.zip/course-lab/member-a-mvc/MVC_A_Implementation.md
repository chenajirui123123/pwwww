# Member A: local account MVC implementation

This stage refactors the account and shared coordination code in the supplied Kotlin/Compose application. It retains SQLite, private images and the existing visual theme. No backend is required.

## Responsibilities

| Layer | Implementation | Responsibility |
|---|---|---|
| View | AuthScreen, LightWelcome, ProfileScreen | Render state and send named account actions |
| Controller | AccountController | Coordinate validation, repository calls and operation results |
| Shared controller infrastructure | OperationCoordinator | Prevent overlapping operations, dispatch background work and publish consistent snapshots |
| Model | AccountRules, Account, AccountRepository, LocalAccountRepository, LocalSessionRepository, LocalStore | Business rules, account persistence and owner-scoped data |
| Android lifecycle container | WardrobeViewModel | Assemble and retain the controllers and one shared LocalStore |

Account views depend on AccountActions. They no longer submit arbitrary LocalStore operations. Repository methods do not depend on Compose. Password validation can be tested independently of Android.

The coordinator reloads the account and wardrobe together. If a model operation or refresh fails, it attempts a fresh snapshot. If that also fails, the visible account and wardrobe are cleared instead of retaining a previous owner's data. Password values are not saved in instance-state Bundles.

The existing SQLite schema and salted PBKDF2 implementation are retained. The persistence order of sign-in and logout is adjusted so the in-memory identity changes only after saving succeeds.

## Scope

Member A's account flows are migrated. B–E continue through an explicitly marked LegacyModuleController compatibility seam and still need their own named controllers. Photo capture and offline clothing recognition are separate upcoming work for member B.

The exact Lecture 14 convention was not available. The implementation demonstrates MVC responsibility separation; the lifecycle-only use of ViewModel should be checked against the lecture before presentation.

## How to inspect

Start with AccountRules, then AccountRepository, AccountController, OperationCoordinator and the account Compose screens. MainActivity only wires the retained objects. See the Chinese step-by-step guide for setup and demonstration instructions.

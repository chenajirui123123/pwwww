package com.wardrobe.atelier.controller

import com.wardrobe.atelier.AppState
import com.wardrobe.atelier.domain.SessionSnapshot
import com.wardrobe.atelier.domain.Wardrobe
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Shared controller infrastructure. One operation at a time protects the active local owner
 * while SQLite, photo import or account work runs. No Compose or Activity references are kept.
 */
class OperationCoordinator(
    private val scope: CoroutineScope,
    private val loadSnapshot: () -> SessionSnapshot,
    private val workerDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    private val mutable = MutableStateFlow(AppState())
    val state = mutable.asStateFlow()

    fun execute(success: String? = null, after: () -> Unit = {}, action: () -> Unit): Job? {
        while (true) {
            val before = mutable.value
            if (before.busy) return null
            if (mutable.compareAndSet(before, before.copy(busy = true, error = null, message = null))) break
        }
        return scope.launch {
            try {
                val snapshot = withContext(workerDispatcher) {
                    action()
                    loadSnapshot()
                }
                mutable.value = AppState(
                    loaded = true, account = snapshot.account, data = snapshot.data, message = success,
                )
            } catch (cancelled: CancellationException) {
                mutable.value = mutable.value.copy(busy = false)
                throw cancelled
            } catch (failure: Exception) {
                // A local owner may already have changed before a snapshot read fails.
                // Recover from the model; never reuse a previous owner's wardrobe blindly.
                val recovered = try {
                    withContext(workerDispatcher) { loadSnapshot() }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) { null }
                mutable.value = AppState(
                    loaded = true, account = recovered?.account, data = recovered?.data ?: Wardrobe(),
                    error = failure.message ?: "操作失败，请重试",
                )
                return@launch
            }
            // View callbacks are outside the storage-error catch: a rendering problem is not a DB failure.
            after()
        }
    }

    fun refresh() { execute { } }
    fun error(message: String) { mutable.value = mutable.value.copy(error = message) }
    fun notify(message: String) { mutable.value = mutable.value.copy(message = message) }
    fun clearError() { mutable.value = mutable.value.copy(error = null) }
    fun clearMessage() { mutable.value = mutable.value.copy(message = null) }
}

package com.wardrobe.atelier

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.content.IntentCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wardrobe.atelier.data.LocalStore
import com.wardrobe.atelier.domain.*
import com.wardrobe.atelier.ui.WardrobeApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val wardrobeModel: WardrobeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) receiveShare(intent)
        setContent { WardrobeApp(wardrobeModel) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        receiveShare(intent)
    }

    private fun receiveShare(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return
        val uri = IntentCompat.getParcelableExtra(incoming, Intent.EXTRA_STREAM, Uri::class.java)
        if (
            incoming.type !in setOf("image/jpeg", "image/png", "image/webp") ||
                uri?.scheme != "content"
        ) {
            wardrobeModel.error("请分享一张 JPEG、PNG 或 WebP 图片")
        } else wardrobeModel.queueSharedImage(uri)
    }
}

/** Lifecycle container and app wiring; account business coordination lives in AccountController. */
class WardrobeViewModel(application: Application) : AndroidViewModel(application) {
    private val store = LocalStore(application)
    private val sessions = com.wardrobe.atelier.data.LocalSessionRepository(store)
    private val operations = com.wardrobe.atelier.controller.OperationCoordinator(viewModelScope, sessions::load)
    private val legacy = com.wardrobe.atelier.controller.LegacyModuleController(store, operations)
    private val incomingImage = MutableStateFlow<Uri?>(null)
    val sharedImage = incomingImage.asStateFlow()
    val state = operations.state
    val accountActions: com.wardrobe.atelier.controller.AccountActions =
        com.wardrobe.atelier.controller.AccountController(
            com.wardrobe.atelier.data.account.LocalAccountRepository(store), operations,
            onLogout = { incomingImage.value = null },
        )

    init {
        // The scope completes only after its background children finish, avoiding close/read races.
        viewModelScope.coroutineContext[kotlinx.coroutines.Job]?.invokeOnCompletion { store.close() }
        operations.refresh()
    }

    fun queueSharedImage(uri: Uri) { incomingImage.value = uri }
    fun consumeSharedImage(uri: Uri) {
        if (incomingImage.value == uri) incomingImage.value = null
    }

    /** Temporary compatibility for B–E. Their migration is documented separately. */
    fun perform(success: String? = "已保存", after: () -> Unit = {}, action: LocalStore.() -> Unit) {
        legacy.perform(success, after, action)
    }
    fun error(text: String) = operations.error(text)
    fun notify(text: String) = operations.notify(text)
    fun clearError() = operations.clearError()
    fun clearMessage() = operations.clearMessage()
}

package com.wardrobe.atelier.data.account

import com.wardrobe.atelier.data.LocalStore

/** Retains the existing SQLite schema and PBKDF2 password implementation. */
class LocalAccountRepository(private val store: LocalStore) : AccountRepository {
    override fun currentAccount() = store.account()
    override fun register(username: String, password: String, nickname: String) =
        store.register(username, password, nickname)
    override fun login(username: String, password: String) = store.login(username, password)
    override fun logout() = store.logout()
    override fun updateNickname(nickname: String) = store.rename(nickname)
    override fun changePassword(oldPassword: String, newPassword: String) =
        store.changePassword(oldPassword, newPassword)
    override fun openLocalWardrobe() = store.openLocalWardrobe()
    override fun openDemoWardrobe() = store.demo()
}

package com.wardrobe.atelier.data

import com.wardrobe.atelier.domain.SessionSnapshot
import com.wardrobe.atelier.domain.Wardrobe

class LocalSessionRepository(private val store: LocalStore) {
    fun load(): SessionSnapshot {
        val account = store.account()
        return SessionSnapshot(account, if (account == null) Wardrobe() else store.snapshot())
    }
}

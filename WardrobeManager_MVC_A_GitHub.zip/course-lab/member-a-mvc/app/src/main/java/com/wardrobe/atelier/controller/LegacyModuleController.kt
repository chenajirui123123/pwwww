package com.wardrobe.atelier.controller

import com.wardrobe.atelier.data.LocalStore

/**
 * Temporary B–E compatibility seam. Those modules have not yet been migrated to named MVC
 * controllers. Account views do not use this API. Remove it after their migrations finish.
 */
class LegacyModuleController(private val store: LocalStore, private val operations: OperationCoordinator) {
    fun perform(success: String?, after: () -> Unit, action: LocalStore.() -> Unit) {
        operations.execute(success, after) { store.action() }
    }
}

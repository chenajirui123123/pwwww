package com.wardrobe.atelier.controller

/** View-facing commands. No SQL, LocalStore, Activity, or Compose types cross this boundary. */
interface AccountActions {
    fun register(username: String, password: String, nickname: String, confirmation: String)
    fun login(username: String, password: String)
    fun logout()
    fun updateNickname(nickname: String, after: () -> Unit = {})
    fun changePassword(oldPassword: String, newPassword: String, confirmation: String, after: () -> Unit = {})
    fun openLocalWardrobe()
    fun openDemoWardrobe()
}

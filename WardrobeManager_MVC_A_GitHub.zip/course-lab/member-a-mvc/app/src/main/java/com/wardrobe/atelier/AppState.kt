package com.wardrobe.atelier

import com.wardrobe.atelier.domain.Account
import com.wardrobe.atelier.domain.Wardrobe

/** Immutable display state, read by Compose and updated by the operation coordinator. */
data class AppState(
    val loaded: Boolean = false,
    val account: Account? = null,
    val data: Wardrobe = Wardrobe(),
    val busy: Boolean = false,
    val error: String? = null,
    val message: String? = null,
)

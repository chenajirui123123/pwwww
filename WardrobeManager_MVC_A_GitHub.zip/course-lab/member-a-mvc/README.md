# 衣序：A 模块单机 MVC 版

基于提供的 `pwwww-main`，完成本机账号模块及公共操作协调的 MVC 改造。
保留 Kotlin、Compose、SQLite、现有衣序主题和中英文界面。

## 开始使用

1. Android Studio 打开本目录（包含 `settings.gradle.kts` 的目录）。
2. 使用 IDE 自带 JDK，准备 Android SDK 36 和 Build-Tools 36.0.0。
3. 等待同步完成，选择 `app` 和模拟器后运行。
4. 本机版不需要服务器。独立预览 APK 会显示“衣序 · A模块预览”。

完整操作和代码阅读顺序见 [A模块：从打开到验收](A模块_从打开到验收.md)。
英文职责说明见 [MVC implementation](MVC_A_Implementation.md)。

## MVC 文件

- View：`ui/App.kt` 的 AuthScreen、`ui/LightScreens.kt` 的 LightWelcome、`ui/Profile.kt` 的 ProfileScreen。
- Controller：`controller/AccountController.kt`、`controller/OperationCoordinator.kt`。
- Model：`domain/AccountRules.kt`、`data/account/`、LocalSessionRepository、LocalStore。
- 生命周期容器：`MainActivity.kt` 中的 WardrobeViewModel。

账号页面通过 AccountActions 发送具名操作，不直接组织 LocalStore 数据访问。
B—E 尚通过明确标注的 LegacyModuleController 兼容层运行，后续由对应成员继续迁移。
拍照和离线识别仍由 B 接入，本阶段没有提供识别模型。

## 验证

```powershell
.\gradlew.bat -PisolatedPreview :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
.\gradlew.bat -PisolatedPreview :app:connectedDebugAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.wardrobe.atelier.AccountMvcJourneyTest
```

该预览环境包名为 `com.wardrobe.atelier.light.preview`，与普通应用分开保存数据。
源码包不包含账号数据库、SDK 本机路径、构建缓存或签名私钥。
老师 Lecture 14 未随材料提供，展示时需核对其 MVC 约定。
